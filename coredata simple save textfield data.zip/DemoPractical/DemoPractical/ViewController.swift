//
//  ViewController.swift
//  DemoPractical
//
//  Created by Mac on 9/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtBOD: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtGender: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtNumber: UITextField!
    
    
    
    var aryData = [String:Any]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func btnActionSave(_ sender: UIButton)
    {
    
        let data = NSEntityDescription.insertNewObject(forEntityName:"Users", into: context)
        
        data.setValue(self.txtName.text!, forKey: "name")
        data.setValue(self.txtEmail.text!, forKey: "email")
        data.setValue(self.txtNumber.text!, forKey: "number")
        data.setValue(self.txtCity.text!, forKey: "city")
        data.setValue(self.txtGender.text!, forKey: "gender")
        data.setValue(self.txtBOD.text!, forKey: "dob")
        
        do{
            try context.save()
        }catch
        {
         print(error.localizedDescription )
        }
        
    }
    
}

