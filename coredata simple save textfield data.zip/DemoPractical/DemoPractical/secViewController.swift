//
//  secViewController.swift
//  DemoPractical
//
//  Created by Mac on 9/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit
import CoreData

class secViewController: UIViewController, UITableViewDataSource,UITableViewDelegate {
   
    @IBOutlet weak var tblView: UITableView!
    
    var aryData:[Users] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.fetchrecord()
        
        tblView.rowHeight = 100

       tblView.reloadData()
    }
    func fetchrecord()
    {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
        
        do
        {
            aryData = try! context.fetch(Users.fetchRequest())
        }
    
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return aryData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  cell =  tableView.dequeueReusableCell(withIdentifier: "cusTableViewCell", for: indexPath)as! cusTableViewCell
        let name = aryData[indexPath.row]
        
        cell.lblName.text = name.name
        cell.lblEmail.text = name.email
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let details:thirdViewController = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "thirdViewController")as! thirdViewController
        
         let data = aryData[indexPath.row]
        
        
        details.strName = "Name: \(data.name!)"
        details.strEmail = "Email: \(data.email!)"
        details.strNumber = "Number: \(data.number!)"
        details.strGender = "Gender: \(data.gender!)"
        details.strCity = "City: \(data.city!)"
        details.strBod = "BOD: \(data.dob!)"
       
        
        navigationController?.pushViewController(details, animated: true)
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            print("Deleted")
            
        
            self.aryData.remove(at: indexPath.row)
            self.tblView.deleteRows(at: [indexPath], with: .automatic)
        self.tblView.reloadData()
        
            
        }
    }
}
