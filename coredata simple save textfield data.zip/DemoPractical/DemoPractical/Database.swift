//
//  Database.swift
//  DemoPractical
//
//  Created by Mac on 9/19/18.
//  Copyright © 2018 agile. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class DataBase
{
    static var share:DataBase = DataBase()
    
     let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func getById(id: NSManagedObjectID) -> NSManagedObject
    {
    return context.object(with: id)
    }
    
    
    
    func deleteEmployee(name: NSManagedObjectID)
    {
                let sugerToDelete = getById(id: name)
                context.delete(sugerToDelete)
                do{
                    try context.save()
                    print("saved.")
                }catch{
                    print(error.localizedDescription)
                }
        }
    
//    func getEmployeeBy(name: String) -> [Users]
//    {
//        var result = [Users]()
//        let fetchRequest: NSFetchRequest = Users.fetchRequest()
//        let predicate = NSPredicate(format: "name == %@","\(name)")
//        fetchRequest.predicate = predicate
//        do{
//            result = try context.fetch(fetchRequest)
//        }catch{
//            print(error.localizedDescription)
//        }
//        return result
//    }
    
    
}
